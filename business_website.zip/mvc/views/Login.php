<div class="login-center">
    <h2>Đăng nhập</h2>
    <form method="POST" id="form_input_login">
        <div class="txt_field">
            <input type="text" name="phoneNumber" required>
            <span></span>
            <label>Số điện thoại</label>
        </div>
        <div class="txt_field">
            <input type="password" name="password" required>
            <span></span>
            <label>Mật khẩu</label>
        </div>
        <div class="pass">Quên mật khẩu?</div>
        <input type="button" class="log-in-button" id="login-button" value="Đăng nhập">
        <div id="content_login"></div>
        <div class="signup_link">
            Bạn là người mới? <a href="/register">Đăng ký</a>
        </div>
        
    </form>
</div>
<!-- <div class="go-to-home-page">
    <a href="/"><i class="fas fa-arrow-left"></i>Trở về trang chủ</a>
</div> -->
